import { Post, CreatePostData, UpdatePostData, PostsResponse } from '../types';

// Mock data
const mockPosts: Post[] = [
  {
    id: '1',
    title: 'Getting Started with React and TypeScript',
    slug: 'getting-started-react-typescript',
    content: `React and TypeScript make a powerful combination for building modern web applications. In this comprehensive guide, we'll explore how to set up a React project with TypeScript and leverage the benefits of static typing.

## Why TypeScript with React?

TypeScript brings several advantages to React development:

- **Type Safety**: Catch errors at compile time rather than runtime
- **Better IDE Support**: Enhanced autocomplete and refactoring capabilities  
- **Improved Documentation**: Types serve as inline documentation
- **Easier Refactoring**: Confident code changes with type checking

## Setting Up Your Project

First, create a new React project with TypeScript:

\`\`\`bash
npx create-react-app my-app --template typescript
# or with Vite
npm create vite@latest my-app -- --template react-ts
\`\`\`

## Component Development

Here's how to create a typed React component:

\`\`\`typescript
interface Props {
  title: string;
  count: number;
  onIncrement: () => void;
}

const Counter: React.FC<Props> = ({ title, count, onIncrement }) => {
  return (
    <div>
      <h2>{title}</h2>
      <p>Count: {count}</p>
      <button onClick={onIncrement}>Increment</button>
    </div>
  );
};
\`\`\`

This approach ensures your components are well-typed and maintainable as your application grows.`,
    excerpt: 'Learn how to combine React with TypeScript for better development experience and code quality.',
    featured_image: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800',
    status: 'published',
    author_id: '1',
    category_id: '1',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z',
    author: {
      id: '1',
      email: 'demo@example.com',
      username: 'demo_user',
      avatar_url: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      created_at: '2024-01-01T00:00:00Z',
    },
    category: {
      id: '1',
      name: 'React',
      slug: 'react',
      description: 'React development tutorials and tips',
      color: '#61DAFB',
      created_at: '2024-01-01T00:00:00Z',
    },
    _count: { comments: 5 }
  },
  {
    id: '2',
    title: 'Modern CSS Techniques for 2024',
    slug: 'modern-css-techniques-2024',
    content: `CSS continues to evolve with new features and techniques that make styling more powerful and intuitive. Let's explore the latest CSS capabilities that every developer should know in 2024.

## Container Queries

Container queries allow you to style elements based on their container's size rather than the viewport:

\`\`\`css
.card {
  container-type: inline-size;
}

@container (min-width: 300px) {
  .card-content {
    display: flex;
    gap: 1rem;
  }
}
\`\`\`

## CSS Grid Subgrid

Subgrid allows nested grids to participate in their parent's grid:

\`\`\`css
.parent {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
}

.child {
  display: grid;
  grid-column: span 2;
  grid-template-columns: subgrid;
}
\`\`\`

## Custom Properties with @property

Define custom properties with type checking:

\`\`\`css
@property --rotation {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}

.element {
  --rotation: 45deg;
  transform: rotate(var(--rotation));
}
\`\`\`

These modern techniques help create more maintainable and responsive designs.`,
    excerpt: 'Discover the latest CSS features and techniques that are changing how we style web applications.',
    featured_image: 'https://images.pexels.com/photos/1591061/pexels-photo-1591061.jpeg?auto=compress&cs=tinysrgb&w=800',
    status: 'published',
    author_id: '1',
    category_id: '2',
    created_at: '2024-01-14T15:30:00Z',
    updated_at: '2024-01-14T15:30:00Z',
    author: {
      id: '1',
      email: 'demo@example.com',
      username: 'demo_user',
      avatar_url: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      created_at: '2024-01-01T00:00:00Z',
    },
    category: {
      id: '2',
      name: 'CSS',
      slug: 'css',
      description: 'CSS tutorials and best practices',
      color: '#1572B6',
      created_at: '2024-01-01T00:00:00Z',
    },
    _count: { comments: 3 }
  },
  {
    id: '3',
    title: 'Building Scalable Node.js APIs',
    slug: 'building-scalable-nodejs-apis',
    content: `Building scalable APIs with Node.js requires careful consideration of architecture, performance, and maintainability. This guide covers essential patterns and practices for creating robust backend services.

## Project Structure

Organize your project with clear separation of concerns:

\`\`\`
src/
├── controllers/
├── middleware/
├── models/
├── routes/
├── services/
├── utils/
└── app.js
\`\`\`

## Error Handling

Implement centralized error handling:

\`\`\`javascript
class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
  }
}

const errorHandler = (err, req, res, next) => {
  const { statusCode = 500, message } = err;
  
  res.status(statusCode).json({
    status: 'error',
    message: process.env.NODE_ENV === 'production' 
      ? 'Something went wrong' 
      : message
  });
};
\`\`\`

## Database Optimization

Use proper indexing and query optimization:

\`\`\`javascript
// Mongoose schema with indexes
const userSchema = new Schema({
  email: { type: String, required: true, unique: true, index: true },
  username: { type: String, required: true, index: true },
  createdAt: { type: Date, default: Date.now, index: true }
});

// Efficient queries with population
const posts = await Post.find({ status: 'published' })
  .populate('author', 'username avatar')
  .sort({ createdAt: -1 })
  .limit(10);
\`\`\`

## Caching Strategy

Implement Redis caching for better performance:

\`\`\`javascript
const redis = require('redis');
const client = redis.createClient();

const cacheMiddleware = (duration) => {
  return async (req, res, next) => {
    const key = req.originalUrl;
    const cached = await client.get(key);
    
    if (cached) {
      return res.json(JSON.parse(cached));
    }
    
    res.sendResponse = res.json;
    res.json = (body) => {
      client.setex(key, duration, JSON.stringify(body));
      res.sendResponse(body);
    };
    
    next();
  };
};
\`\`\`

Following these patterns will help you build APIs that can scale with your application's growth.`,
    excerpt: 'Learn essential patterns and practices for building scalable and maintainable Node.js APIs.',
    featured_image: 'https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=800',
    status: 'published',
    author_id: '1',
    category_id: '3',
    created_at: '2024-01-13T09:15:00Z',
    updated_at: '2024-01-13T09:15:00Z',
    author: {
      id: '1',
      email: 'demo@example.com',
      username: 'demo_user',
      avatar_url: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      created_at: '2024-01-01T00:00:00Z',
    },
    category: {
      id: '3',
      name: 'Node.js',
      slug: 'nodejs',
      description: 'Backend development with Node.js',
      color: '#339933',
      created_at: '2024-01-01T00:00:00Z',
    },
    _count: { comments: 8 }
  }
];

class PostService {
  async getPosts(page = 1, limit = 9, search = '', categoryId = ''): Promise<PostsResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    let filteredPosts = [...mockPosts];
    
    // Filter by search query
    if (search) {
      filteredPosts = filteredPosts.filter(post => 
        post.title.toLowerCase().includes(search.toLowerCase()) ||
        post.content.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    // Filter by category
    if (categoryId) {
      filteredPosts = filteredPosts.filter(post => post.category_id === categoryId);
    }
    
    // Pagination
    const total = filteredPosts.length;
    const totalPages = Math.ceil(total / limit);
    const offset = (page - 1) * limit;
    const paginatedPosts = filteredPosts.slice(offset, offset + limit);
    
    return {
      data: paginatedPosts,
      meta: {
        page,
        limit,
        total,
        totalPages,
      },
    };
  }

  async getPost(id: string): Promise<Post> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const post = mockPosts.find(p => p.id === id);
    if (!post) {
      throw new Error('Post not found');
    }
    
    return post;
  }

  async createPost(data: CreatePostData): Promise<Post> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newPost: Post = {
      id: Date.now().toString(),
      ...data,
      slug: data.title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, ''),
      author_id: '1',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      author: {
        id: '1',
        email: 'demo@example.com',
        username: 'demo_user',
        avatar_url: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
        created_at: '2024-01-01T00:00:00Z',
      },
      _count: { comments: 0 }
    };
    
    mockPosts.unshift(newPost);
    return newPost;
  }

  async updatePost(data: UpdatePostData): Promise<Post> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const index = mockPosts.findIndex(p => p.id === data.id);
    if (index === -1) {
      throw new Error('Post not found');
    }
    
    const updatedPost = {
      ...mockPosts[index],
      ...data,
      updated_at: new Date().toISOString(),
    };
    
    if (data.title) {
      updatedPost.slug = data.title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '');
    }
    
    mockPosts[index] = updatedPost;
    return updatedPost;
  }

  async deletePost(id: string): Promise<void> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const index = mockPosts.findIndex(p => p.id === id);
    if (index === -1) {
      throw new Error('Post not found');
    }
    
    mockPosts.splice(index, 1);
  }
}

export const postService = new PostService();