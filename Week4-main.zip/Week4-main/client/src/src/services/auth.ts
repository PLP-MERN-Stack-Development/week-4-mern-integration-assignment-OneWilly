import { User } from '../types';

// Mock authentication service
class AuthService {
  private storageKey = 'blog_user';

  async getCurrentUser(): Promise<User | null> {
    try {
      const userData = localStorage.getItem(this.storageKey);
      return userData ? JSON.parse(userData) : null;
    } catch {
      return null;
    }
  }

  async login(email: string, password: string): Promise<User> {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (email === 'demo@example.com' && password === 'password') {
      const user: User = {
        id: '1',
        email,
        username: 'demo_user',
        avatar_url: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
        created_at: new Date().toISOString(),
      };
      
      localStorage.setItem(this.storageKey, JSON.stringify(user));
      return user;
    }
    
    throw new Error('Invalid credentials');
  }

  async register(email: string, password: string, username: string): Promise<User> {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const user: User = {
      id: Date.now().toString(),
      email,
      username,
      avatar_url: `https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2`,
      created_at: new Date().toISOString(),
    };
    
    localStorage.setItem(this.storageKey, JSON.stringify(user));
    return user;
  }

  async logout(): Promise<void> {
    localStorage.removeItem(this.storageKey);
  }

  async updateProfile(data: Partial<User>): Promise<User> {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const currentUser = await this.getCurrentUser();
    if (!currentUser) {
      throw new Error('No user logged in');
    }
    
    const updatedUser = { ...currentUser, ...data };
    localStorage.setItem(this.storageKey, JSON.stringify(updatedUser));
    return updatedUser;
  }
}

export const authService = new AuthService();