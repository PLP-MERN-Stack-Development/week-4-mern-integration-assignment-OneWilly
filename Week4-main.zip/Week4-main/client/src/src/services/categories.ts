import { Category } from '../types';

const mockCategories: Category[] = [
  {
    id: '1',
    name: 'React',
    slug: 'react',
    description: 'React development tutorials and tips',
    color: '#61DAFB',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'CSS',
    slug: 'css',
    description: 'CSS tutorials and best practices',
    color: '#1572B6',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '3',
    name: 'Node.js',
    slug: 'nodejs',
    description: 'Backend development with Node.js',
    color: '#339933',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '4',
    name: 'JavaScript',
    slug: 'javascript',
    description: 'Modern JavaScript development',
    color: '#F7DF1E',
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '5',
    name: 'TypeScript',
    slug: 'typescript',
    description: 'TypeScript programming and best practices',
    color: '#3178C6',
    created_at: '2024-01-01T00:00:00Z',
  },
];

class CategoryService {
  async getCategories(): Promise<Category[]> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 200));
    return [...mockCategories];
  }

  async createCategory(data: Omit<Category, 'id' | 'created_at'>): Promise<Category> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newCategory: Category = {
      id: Date.now().toString(),
      ...data,
      created_at: new Date().toISOString(),
    };
    
    mockCategories.push(newCategory);
    return newCategory;
  }
}

export const categoryService = new CategoryService();