import React from 'react';
import PostForm from '../components/Blog/PostForm';

const CreatePostPage: React.FC = () => {
  return <PostForm mode="create" />;
};

export default CreatePostPage;