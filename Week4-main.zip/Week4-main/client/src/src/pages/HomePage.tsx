import React from 'react';
import { Link } from 'react-router-dom';
import { usePost } from '../contexts/PostContext';
import { useAuth } from '../contexts/AuthContext';
import PostCard from '../components/Blog/PostCard';
import SearchAndFilter from '../components/Blog/SearchAndFilter';
import Pagination from '../components/Blog/Pagination';
import LoadingSpinner from '../components/UI/LoadingSpinner';
import { Plus, TrendingUp, Users, BookOpen } from 'lucide-react';

const HomePage: React.FC = () => {
  const { posts, loading, meta } = usePost();
  const { user } = useAuth();

  const stats = [
    {
      label: 'Total Posts',
      value: meta?.total || 0,
      icon: BookOpen,
      color: 'bg-blue-500',
    },
    {
      label: 'Active Writers',
      value: '12',
      icon: Users,
      color: 'bg-green-500',
    },
    {
      label: 'Views This Month',
      value: '45.2K',
      icon: TrendingUp,
      color: 'bg-purple-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Welcome to{' '}
              <span className="text-blue-600">DevBlog</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Discover the latest insights, tutorials, and best practices in web development. 
              Share your knowledge and learn from the community.
            </p>
            
            {user ? (
              <Link
                to="/create"
                className="inline-flex items-center space-x-2 bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-5 w-5" />
                <span>Write Your First Post</span>
              </Link>
            ) : (
              <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
                <Link
                  to="/register"
                  className="inline-flex items-center bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors"
                >
                  Get Started
                </Link>
                <Link
                  to="/login"
                  className="inline-flex items-center text-gray-700 hover:text-blue-600 transition-colors"
                >
                  Already have an account? Sign in
                </Link>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="flex items-center space-x-4">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-gray-600">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Search and Filters */}
          <SearchAndFilter />

          {/* Loading State */}
          {loading ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner size="lg" />
            </div>
          ) : (
            <>
              {/* Posts Grid */}
              {posts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                  {posts.map(post => (
                    <PostCard key={post.id} post={post} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-500 mb-4">
                    <BookOpen className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-xl font-medium">No posts found</h3>
                    <p className="mt-2">Try adjusting your search or filters.</p>
                  </div>
                  {user && (
                    <Link
                      to="/create"
                      className="inline-flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Plus className="h-4 w-4" />
                      <span>Create the first post</span>
                    </Link>
                  )}
                </div>
              )}

              {/* Pagination */}
              <Pagination />
            </>
          )}
        </div>
      </section>
    </div>
  );
};

export default HomePage;