import React from 'react';
import { usePost } from '../../contexts/PostContext';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import Button from '../UI/Button';

const Pagination: React.FC = () => {
  const { meta, currentPage, searchQuery, selectedCategory, fetchPosts } = usePost();

  if (!meta || meta.totalPages <= 1) {
    return null;
  }

  const handlePageChange = (page: number) => {
    fetchPosts(page, searchQuery, selectedCategory);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getPageNumbers = () => {
    const pages = [];
    const totalPages = meta.totalPages;
    const current = currentPage;

    // Always show first page
    pages.push(1);

    // Add ellipsis if needed
    if (current > 3) {
      pages.push('...');
    }

    // Add pages around current page
    for (let i = Math.max(2, current - 1); i <= Math.min(totalPages - 1, current + 1); i++) {
      pages.push(i);
    }

    // Add ellipsis if needed
    if (current < totalPages - 2) {
      pages.push('...');
    }

    // Always show last page if more than 1 page
    if (totalPages > 1) {
      pages.push(totalPages);
    }

    // Remove duplicates
    return pages.filter((page, index, arr) => arr.indexOf(page) === index);
  };

  return (
    <div className="flex items-center justify-between bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="text-sm text-gray-700">
        Showing {((currentPage - 1) * meta.limit) + 1} to {Math.min(currentPage * meta.limit, meta.total)} of {meta.total} results
      </div>

      <div className="flex items-center space-x-2">
        {/* Previous Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Previous
        </Button>

        {/* Page Numbers */}
        <div className="flex items-center space-x-1">
          {getPageNumbers().map((page, index) => (
            <React.Fragment key={index}>
              {page === '...' ? (
                <span className="px-3 py-2 text-gray-500">...</span>
              ) : (
                <button
                  onClick={() => handlePageChange(page as number)}
                  className={`px-3 py-2 text-sm rounded-lg transition-colors ${
                    currentPage === page
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {page}
                </button>
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Next Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === meta.totalPages}
        >
          Next
          <ChevronRight className="h-4 w-4 ml-1" />
        </Button>
      </div>
    </div>
  );
};

export default Pagination;