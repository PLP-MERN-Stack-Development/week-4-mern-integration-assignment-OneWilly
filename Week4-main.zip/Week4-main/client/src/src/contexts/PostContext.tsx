import React, { createContext, useContext, useEffect, useState } from 'react';
import { Post, Category, PostsResponse, CreatePostData, UpdatePostData } from '../types';
import { postService } from '../services/posts';
import { categoryService } from '../services/categories';

interface PostContextType {
  posts: Post[];
  categories: Category[];
  loading: boolean;
  meta: PostsResponse['meta'] | null;
  searchQuery: string;
  selectedCategory: string;
  currentPage: number;
  fetchPosts: (page?: number, search?: string, categoryId?: string) => Promise<void>;
  fetchCategories: () => Promise<void>;
  createPost: (data: CreatePostData) => Promise<Post>;
  updatePost: (data: UpdatePostData) => Promise<Post>;
  deletePost: (id: string) => Promise<void>;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (categoryId: string) => void;
  setCurrentPage: (page: number) => void;
}

const PostContext = createContext<PostContextType | undefined>(undefined);

export const usePost = () => {
  const context = useContext(PostContext);
  if (context === undefined) {
    throw new Error('usePost must be used within a PostProvider');
  }
  return context;
};

interface PostProviderProps {
  children: React.ReactNode;
}

export const PostProvider: React.FC<PostProviderProps> = ({ children }) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [meta, setMeta] = useState<PostsResponse['meta'] | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const fetchPosts = async (page = 1, search = searchQuery, categoryId = selectedCategory) => {
    setLoading(true);
    try {
      const response = await postService.getPosts(page, 9, search, categoryId);
      setPosts(response.data);
      setMeta(response.meta);
      setCurrentPage(page);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const data = await categoryService.getCategories();
      setCategories(data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const createPost = async (data: CreatePostData) => {
    const newPost = await postService.createPost(data);
    await fetchPosts(1);
    return newPost;
  };

  const updatePost = async (data: UpdatePostData) => {
    const updatedPost = await postService.updatePost(data);
    await fetchPosts(currentPage);
    return updatedPost;
  };

  const deletePost = async (id: string) => {
    await postService.deletePost(id);
    await fetchPosts(currentPage);
  };

  useEffect(() => {
    fetchPosts();
    fetchCategories();
  }, []);

  const value = {
    posts,
    categories,
    loading,
    meta,
    searchQuery,
    selectedCategory,
    currentPage,
    fetchPosts,
    fetchCategories,
    createPost,
    updatePost,
    deletePost,
    setSearchQuery,
    setSelectedCategory,
    setCurrentPage,
  };

  return <PostContext.Provider value={value}>{children}</PostContext.Provider>;
};