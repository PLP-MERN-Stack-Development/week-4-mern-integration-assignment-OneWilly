import Joi from 'joi';

export const validatePost = (data, isUpdate = false) => {
  const schema = Joi.object({
    title: Joi.string().min(3).max(200).when(isUpdate, {
      is: true,
      then: Joi.optional(),
      otherwise: Joi.required()
    }),
    content: Joi.string().min(10).when(isUpdate, {
      is: true,
      then: Joi.optional(),
      otherwise: Joi.required()
    }),
    excerpt: Joi.string().min(10).max(500).when(isUpdate, {
      is: true,
      then: Joi.optional(),
      otherwise: Joi.required()
    }),
    category: Joi.string().hex().length(24).when(isUpdate, {
      is: true,
      then: Joi.optional(),
      otherwise: Joi.required()
    }),
    featured_image: Joi.string().uri().allow('', null).optional(),
    status: Joi.string().valid('draft', 'published').optional(),
    tags: Joi.array().items(Joi.string().trim()).optional()
  });

  return schema.validate(data);
};

export const validateCategory = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(50).required(),
    description: Joi.string().max(200).optional(),
    color: Joi.string().pattern(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/).optional()
  });

  return schema.validate(data);
};

export const validateUser = (data, isUpdate = false) => {
  const schema = Joi.object({
    username: Joi.string().min(3).max(30).when(isUpdate, {
      is: true,
      then: Joi.optional(),
      otherwise: Joi.required()
    }),
    email: Joi.string().email().when(isUpdate, {
      is: true,
      then: Joi.optional(),
      otherwise: Joi.required()
    }),
    password: Joi.string().min(6).when(isUpdate, {
      is: true,
      then: Joi.optional(),
      otherwise: Joi.required()
    }),
    avatar_url: Joi.string().uri().allow('', null).optional()
  });

  return schema.validate(data);
};