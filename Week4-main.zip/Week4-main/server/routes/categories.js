import express from 'express';
import Category from '../models/Category.js';
import authMiddleware from '../middleware/auth.js';
import { validateCategory } from '../utils/validation.js';

const router = express.Router();

// Helper function to create slug
const createSlug = async (name) => {
  let slug = name.toLowerCase()
    .replace(/[^a-z0-9 -]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim('-');

  let uniqueSlug = slug;
  let counter = 1;

  while (true) {
    const existing = await Category.findOne({ slug: uniqueSlug });
    if (!existing) break;
    
    uniqueSlug = `${slug}-${counter}`;
    counter++;
  }

  return uniqueSlug;
};

// Get all categories
router.get('/', async (req, res, next) => {
  try {
    const categories = await Category.find().sort({ name: 1 });
    res.json(categories);
  } catch (error) {
    next(error);
  }
});

// Create category
router.post('/', authMiddleware, async (req, res, next) => {
  try {
    const { error } = validateCategory(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const { name, description, color } = req.body;
    const slug = await createSlug(name);

    const category = new Category({
      name,
      slug,
      description,
      color
    });

    await category.save();
    res.status(201).json(category);
  } catch (error) {
    next(error);
  }
});

export default router;