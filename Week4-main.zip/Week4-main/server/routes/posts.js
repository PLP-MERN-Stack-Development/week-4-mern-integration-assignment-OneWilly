import express from 'express';
import { 
  getPosts, 
  getPost, 
  createPost, 
  updatePost, 
  deletePost 
} from '../controllers/postController.js';
import authMiddleware from '../middleware/auth.js';

const router = express.Router();

// Public routes
router.get('/', getPosts);
router.get('/:id', getPost);

// Protected routes
router.post('/', authMiddleware, createPost);
router.put('/:id', authMiddleware, updatePost);
router.delete('/:id', authMiddleware, deletePost);

export default router;