import Post from '../models/Post.js';
import Category from '../models/Category.js';
import { validatePost } from '../utils/validation.js';

// Helper function to create slug
const createSlug = async (title, model, excludeId = null) => {
  let slug = title.toLowerCase()
    .replace(/[^a-z0-9 -]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim('-');

  let uniqueSlug = slug;
  let counter = 1;

  while (true) {
    const query = { slug: uniqueSlug };
    if (excludeId) query._id = { $ne: excludeId };
    
    const existing = await model.findOne(query);
    if (!existing) break;
    
    uniqueSlug = `${slug}-${counter}`;
    counter++;
  }

  return uniqueSlug;
};

// Get all posts with pagination and filtering
export const getPosts = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 9;
    const skip = (page - 1) * limit;
    const search = req.query.search || '';
    const category = req.query.category || '';
    const status = req.query.status || 'published';

    // Build query
    let query = { status };

    if (search) {
      query.$text = { $search: search };
    }

    if (category) {
      query.category = category;
    }

    // Execute query with population
    const posts = await Post.find(query)
      .populate('author', 'username email avatar_url')
      .populate('category', 'name slug color')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await Post.countDocuments(query);
    const totalPages = Math.ceil(total / limit);

    res.json({
      data: posts,
      meta: {
        page,
        limit,
        total,
        totalPages
      }
    });
  } catch (error) {
    next(error);
  }
};

// Get single post by ID or slug
export const getPost = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Try to find by ID first, then by slug
    let post = await Post.findById(id)
      .populate('author', 'username email avatar_url')
      .populate('category', 'name slug color');

    if (!post) {
      post = await Post.findOne({ slug: id })
        .populate('author', 'username email avatar_url')
        .populate('category', 'name slug color');
    }

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Increment view count
    post.views += 1;
    await post.save();

    res.json(post);
  } catch (error) {
    next(error);
  }
};

// Create new post
export const createPost = async (req, res, next) => {
  try {
    const { error } = validatePost(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const { title, content, excerpt, category, featured_image, status, tags } = req.body;

    // Generate unique slug
    const slug = await createSlug(title, Post);

    // Verify category exists
    const categoryDoc = await Category.findById(category);
    if (!categoryDoc) {
      return res.status(400).json({ message: 'Invalid category' });
    }

    const post = new Post({
      title,
      slug,
      content,
      excerpt,
      category,
      featured_image,
      status: status || 'draft',
      tags: tags || [],
      author: req.user.id
    });

    await post.save();
    
    // Populate the response
    await post.populate('author', 'username email avatar_url');
    await post.populate('category', 'name slug color');

    // Update category post count
    categoryDoc.postCount += 1;
    await categoryDoc.save();

    res.status(201).json(post);
  } catch (error) {
    next(error);
  }
};

// Update post
export const updatePost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { error } = validatePost(req.body, true);
    
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const post = await Post.findById(id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Check if user owns the post or is admin
    if (post.author.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to update this post' });
    }

    const { title, content, excerpt, category, featured_image, status, tags } = req.body;

    // Update slug if title changed
    if (title && title !== post.title) {
      post.slug = await createSlug(title, Post, post._id);
    }

    // Update fields
    Object.assign(post, {
      title: title || post.title,
      content: content || post.content,
      excerpt: excerpt || post.excerpt,
      category: category || post.category,
      featured_image: featured_image !== undefined ? featured_image : post.featured_image,
      status: status || post.status,
      tags: tags || post.tags
    });

    await post.save();
    
    // Populate the response
    await post.populate('author', 'username email avatar_url');
    await post.populate('category', 'name slug color');

    res.json(post);
  } catch (error) {
    next(error);
  }
};

// Delete post
export const deletePost = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const post = await Post.findById(id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Check if user owns the post or is admin
    if (post.author.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to delete this post' });
    }

    // Update category post count
    const category = await Category.findById(post.category);
    if (category) {
      category.postCount = Math.max(0, category.postCount - 1);
      await category.save();
    }

    await Post.findByIdAndDelete(id);

    res.json({ message: 'Post deleted successfully' });
  } catch (error) {
    next(error);
  }
};